import Hero from "@/components/Hero";
import ProofSection from "@/components/ProofSection";
import PricingTable from "@/components/PricingTable";
import FAQ from "@/components/FAQ";
import Script from "next/script";
import { waLink } from "@/lib/site";

export const metadata = {
  title: "Marketplace Makeover — Listing rapi, penjualan naik. — Valtren Corp",
  description: "Bikin listing yang diklik dan dibeli: judul, foto, copy, atribut, dan bundle yang pas.",
};

export default function Page() {
  const plans = [{"name": "Starter", "suits": "Listing dasar", "price": 399000, "features": ["Riset judul produk", "Optimasi foto", "Copy & bullet benefit", "Template Q&A & kebijakan"]}, {"name": "Pro", "suits": "SKU menengah", "price": 899000, "features": ["10 listing makeover", "Variasi & atribut", "Banner promo & bundle", "Optimasi kategori & tag"]}, {"name": "Scale", "suits": "Toko besar", "price": 1499000, "features": ["25 listing makeover", "SOP foto & copy", "Rencana iklan internal", "Audit & roadmap 30 hari"]}].map(p => ({...p, ctaHref: waLink("Marketplace Makeover — Listing rapi, penjualan naik. — " + p.name)}));
  return (
    <>
      <Hero title="Marketplace Makeover — Listing rapi, penjualan naik." subtitle="Bikin listing yang diklik dan dibeli: judul, foto, copy, atribut, dan bundle yang pas." calendly={process.env.NEXT_PUBLIC_CALENDLY_URL} />
      <ProofSection bullets={["CTR listing naik", "Conversion rate membaik", "Bounce turun"]} />
      <PricingTable plans={plans} />
      <FAQ items={[{"q": "Platform?", "a": "Shopee & Tokopedia; bisa adapt platform lain."}, {"q": "Termasuk foto?", "a": "Termasuk pedoman & optimasi; produksi foto add-on."}, {"q": "Termasuk iklan?", "a": "Tidak. Kami beri rekomendasi kampanye awal."}]} />
      <Script type="application/ld+json" id="jsonld" dangerouslySetInnerHTML={{__html: JSON.stringify({"@context": "https://schema.org", "@type": "Service", "name": "Marketplace Listing Makeover", "provider": {"@type": "Organization", "name": "Valtren Corp"}})}} />
    </>
  );
}
