import Hero from "@/components/Hero";
import ProofSection from "@/components/ProofSection";
import PricingTable from "@/components/PricingTable";
import FAQ from "@/components/FAQ";
import Script from "next/script";
import { waLink } from "@/lib/site";

export const metadata = {
  title: "Pixel & Conversion Audit — Data bersih, iklan irit. — Valtren Corp",
  description: "Rapikan event, hilangkan duplikasi, tetapkan standar penamaan, dan ukur yang penting. Biar optimasi berbasis data beneran.",
};

export default function Page() {
  const plans = [{"name": "Starter", "suits": "UMKM iklan kecil", "price": 499000, "features": ["Audit GA4 + Meta/TikTok", "Mapping event→goal", "Checklist prioritas", "UTM builder"]}, {"name": "Pro", "suits": "Spend menengah", "price": 1199000, "features": ["Implement GTM", "Enhanced events", "Server-side readiness", "Dashboard ROAS"]}, {"name": "Scale", "suits": "Aggressive ads", "price": 1999000, "features": ["Plan server-side", "QA & debug", "Dokumentasi SOP", "Roadmap 90 hari"]}].map(p => ({...p, ctaHref: waLink("Pixel & Conversion Audit — Data bersih, iklan irit. — " + p.name)}));
  return (
    <>
      <Hero title="Pixel & Conversion Audit — Data bersih, iklan irit." subtitle="Rapikan event, hilangkan duplikasi, tetapkan standar penamaan, dan ukur yang penting. Biar optimasi berbasis data beneran." calendly={process.env.NEXT_PUBLIC_CALENDLY_URL} />
      <ProofSection bullets={["Event duplikat & misfiring teratasi", "CPA turun setelah sinyal bersih", "LTV & funnel terbaca"]} />
      <PricingTable plans={plans} />
      <FAQ items={[{"q": "Include implementasi?", "a": "Starter audit; Pro/Scale termasuk implementasi kunci."}, {"q": "Perlu akses apa?", "a": "GA4, Tag Manager (jika ada), admin pixel (Meta/TikTok)."}, {"q": "Durasi?", "a": "Audit 2–3 hari kerja; implementasi tergantung kompleksitas."}]} />
      <Script type="application/ld+json" id="jsonld" dangerouslySetInnerHTML={{__html: JSON.stringify({"@context": "https://schema.org", "@type": "Service", "name": "Pixel & Conversion Audit", "provider": {"@type": "Organization", "name": "Valtren Corp"}})}} />
    </>
  );
}
