import Hero from "@/components/Hero";
import FeatureList from "@/components/FeatureList";
import Link from "next/link";

const SERVICES = [
  { slug: "gbp-sprint", name: "GBP Sprint" },
  { slug: "wa-funnel", name: "WA Funnel" },
  { slug: "one-page-offer", name: "One-Page Offer" },
  { slug: "pixel-audit", name: "Pixel & Conversion Audit" },
  { slug: "marketplace-makeover", name: "Marketplace Makeover" },
  { slug: "asaas", name: "Appointment Setter (ASaaS)" },
  { slug: "local-cpl", name: "Local Lead-Gen (CPL)" },
  { slug: "review-rescue", name: "Review & Reputation Rescue" },
  { slug: "notion-mini-crm", name: "Notion Mini-CRM UMKM" },
  { slug: "wa-catalog", name: "WA Catalog & QR Menu" },
  { slug: "copy-revamp", name: "Copy Revamp (High-Friction)" },
  { slug: "ugc-broker", name: "Broker UGC" },
  { slug: "promo-merdeka", name: "Promo Merdeka Kit" },
];

export default function Page() {
  return (
    <>
      <Hero
        title="Valtren Corp — Growth tanpa drama. Cashflow dulu, scale belakangan."
        subtitle="Kami bikin yang kompleks jadi simpel: landing satu hari jadi, WA funnel, audit konversi, makeover marketplace, dan mesin lead-gen lokal. Hasil nyata, bukan wacana."
        calendly={process.env.NEXT_PUBLIC_CALENDLY_URL}
      />

      <FeatureList items={[
        { kicker: "Cepat", title: "One-Page Offer", desc: "Landing page jadi dalam 24 jam, siap tempur untuk iklan & WA." },
        { kicker: "Akurat", title: "Pixel & Conversion Audit", desc: "Event rapi, data bersih, ROAS kebaca. Habis gelap terbit closing."},
        { kicker: "Lokal", title: "GBP + CPL Machine", desc: "Maps & leads lokal yang bisa diukur dan diskalakan."}
      ]}/>

      <section className="container py-8">
        <h2 className="text-2xl font-semibold mb-4">Layanan</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {SERVICES.map(s => (
            <Link key={s.slug} href={`/${s.slug}`} className="card p-5 hover:border-emerald-400/60 transition">
              <div className="text-white/90 font-semibold">{s.name}</div>
              <div className="text-white/60 text-sm mt-1">/{s.slug}</div>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
