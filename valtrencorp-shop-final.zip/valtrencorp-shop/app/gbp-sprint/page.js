import Hero from "@/components/Hero";
import ProofSection from "@/components/ProofSection";
import PricingTable from "@/components/PricingTable";
import FAQ from "@/components/FAQ";
import Script from "next/script";
import { waLink } from "@/lib/site";

export const metadata = {
  title: "GBP Sprint — Naik di Maps, naik di omset. — Valtren Corp",
  description: "Optimasi Google Business Profile biar bisnis kamu nongol di 3-Pack. Rapi, cepat, terukur.",
};

export default function Page() {
  const plans = [{"name": "Starter", "suits": "UMKM baru mulai", "price": 499000, "features": ["Audit & perbaikan NAP", "Kategori & keyword lokal prioritas", "Foto & postingan awal (3)", "Optimasi jam operasional & layanan", "Panduan minta review"]}, {"name": "Pro", "suits": "Cabang/traffic stagnan", "price": 899000, "features": ["Semua Starter + 5 postingan", "Perapihan duplikat", "Optimasi Q&A & produk/jasa", "Nomor tracking & UTM", "Template balas review (10x)"]}, {"name": "Scale", "suits": "Multi-cabang, agresif", "price": 1499000, "features": ["Semua Pro + 10 postingan", "Riset area sekunder", "Boost foto & review 4 minggu", "Report KPI", "Roadmap 30 hari"]}].map(p => ({...p, ctaHref: waLink("GBP Sprint — Naik di Maps, naik di omset. — " + p.name)}));
  return (
    <>
      <Hero title="GBP Sprint — Naik di Maps, naik di omset." subtitle="Optimasi Google Business Profile biar bisnis kamu nongol di 3-Pack. Rapi, cepat, terukur." calendly={process.env.NEXT_PUBLIC_CALENDLY_URL} />
      <ProofSection bullets={["Listing tampil di 3-pack untuk kata kunci utama", "Panggilan telepon & rute naik terukur (UTM + nomor tracking)", "Perbaikan rating & volume review dalam 2–4 minggu"]} />
      <PricingTable plans={plans} />
      <FAQ items={[{"q": "Butuh akses apa saja?", "a": "Akses manager GBP, alamat, nomor aktif, foto lokasi, jam operasional."}, {"q": "Berapa lama hasil terlihat?", "a": "Biasanya 7–14 hari untuk visibilitas, review/foto baru mempercepat."}, {"q": "Apakah termasuk iklan?", "a": "Tidak. Fokus organik. Iklan bisa add-on."}]} />
      <Script type="application/ld+json" id="jsonld" dangerouslySetInnerHTML={{__html: JSON.stringify({"@context": "https://schema.org", "@type": "Service", "name": "GBP Sprint", "provider": {"@type": "Organization", "name": "Valtren Corp"}})}} />
    </>
  );
}
