# ValtrenCorp.shop — Next.js + Tailwind (Subfolder-first)

Quickstart:
1) cp .env.example .env.local
2) npm install
3) npm run dev

Deploy (Vercel): set env vars, point domain.
